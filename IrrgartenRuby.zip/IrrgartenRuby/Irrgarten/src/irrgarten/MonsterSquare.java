package irrgarten;
/**
 *
 * @author juanma
 */
public class MonsterSquare {
    
    private int row;
    private int col;
    private Monster monsters;
    
    
}
