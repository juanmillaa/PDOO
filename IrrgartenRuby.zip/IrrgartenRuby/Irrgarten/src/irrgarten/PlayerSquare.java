package irrgarten;
/**
 *
 * @author juanma
 */
public class PlayerSquare {
    
    private int row;
    private int col;    
    private Player player;
}
