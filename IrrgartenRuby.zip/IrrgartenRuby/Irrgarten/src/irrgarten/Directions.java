package irrgarten;

/**
 *
 * @author juanma
 */
 public enum Directions {LEFT, RIGHT, UP, DOWN}