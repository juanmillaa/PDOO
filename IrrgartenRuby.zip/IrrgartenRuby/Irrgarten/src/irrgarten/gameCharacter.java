package irrgarten;

/**
 *
 * @author juanma
 */
 enum GameCharacter {PLAYER, MONSTER}
