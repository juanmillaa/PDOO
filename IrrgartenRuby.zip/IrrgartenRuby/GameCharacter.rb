module Irrgarten
    module GameCharacter
        PLAYER = :player
        MONSTER = :monster
    end
end