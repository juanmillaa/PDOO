require_relative "Weapon"
require_relative "Shield"
require_relative "Dice"
require_relative "Directions"

module Irrgarten
  class Player
    @@MAX_WEAPONS = 2
    @@MAX_SHIELDS = 3
    @@INITIAL_HEALTH = 10
    @@HITS2LOSE = 3

    def initialize(number, intelligence,strength)
      @name = "#Player #{@number}"
      @number = number
      @intelligence = intelligence
      @strength = strength
      @health = @@INITIAL_HEALTH
      @row = 0
      @col = 0
      @consecutiveHits = 0
      @weapons = Array.new
      @shields = Array.new
    end

    def resurrect
      @health = @@INITIAL_HEALTH
      @weapons.clear
      @shields.clear
      @consecutiveHits = 0
    end

    attr_reader :row, :col, :number

    def set_pos(row, col)
      @row = row
      @col = col
    end

    def dead   
      return @health <= 0
    end
    
    def attack
      return (@strength + self.sum_weapons)
    end

    def defend(received_attack)
      lose = manage_hit(received_attack)
      return lose 
    end

    def receive_weapon(w)
      for wi in @weapons
        discard = wi.discard
        if(discard)then
          @weapons.delete(wi)
        end
      end
      if(@weapons.size < @@MAX_WEAPONS)then
        @weapons.push(w)
      end
    end

    def to_s
      "#{@name}, #{@intelligence} puntos de inteligencia, #{@health} puntos de vida"
    end

    def sum_weapons
      sum = 0.0;
      for weapon in @weapons
        sum += weapon.attack
      end
      return sum
    end
      
    def sum_shields
      sum = 0.0;
      for shield in @shields
        sum += shield.protect 
      end
      return sum
    end
    
    def defensive_energy
      return (@intelligence + self.sum_shields)
    end

    def new_weapon
      _weapon = Weapon.new(Dice.weapon_power,Dice.uses_left)
      return _weapon
    end
    def new_shield
      _shield = Shield.new(Dice.random_health,Dice.uses_left)
      return _shield
    end

    def reset_hits
      @consecutiveHits = 0
    end

    def got_wounded
      @health -= 1
    end

    def inc_consecutive_hits
      @consecutiveHits += 1
    end
    
    def move(direction,validMoves)
      size = validMoves.size
      contained = validMoves.include?(direction)
      if(size > 0 && !contained)then
        return validMoves[0]
      else
        return direction 
      end
    end

    

    def receive_shield(s)
      for si in @shields
        discard = si.discard
        if(discard)then
          @shields.delete(si)
        end
      end
      if(@shields.size < @@MAX_SHIELDS)then
        @shields.push(s)
      end
    end

    def receive_reward 
      w_reward = Dice.weapons_reward
      s_reward = Dice.shields_reward
      for i in 0...w_reward
        wnew = new_weapon
        receive_weapon(wnew)
      end
      for i in 0...s_reward
        snew = new_shield
        receive_shield(snew)
      end
      extra_health = Dice.health_reward
      @health += extra_health
    end

    def manage_hit(received_attack)
      defense = self.defensive_energy
      if(defense < received_attack)then
        self.got_wounded
        self.inc_consecutive_hits
      else
        self.reset_hits
      end
      lose = false
      if(@consecutiveHits == @@HITS2LOSE || self.dead)then
        self.reset_hits
        lose = true
      end
      return lose 
    end

    private :receive_weapon, :receive_shield, :new_weapon, :new_shield, :sum_weapons, :sum_shields, :defensive_energy, :manage_hit, :reset_hits, :got_wounded, :inc_consecutive_hits

  end
  
end
