require_relative "CombatElement"
module Irrgarten
  class Shield <  CombatElement
    def initialize(iProtection, iUses)
      super(iProtection, iUses)
    end
    
    def protect
      produceEffect
    end

    def discard
      Dice.discard_element(@uses)
    end
    
    def to_s
      "S" + super
    end
  end
  
end
