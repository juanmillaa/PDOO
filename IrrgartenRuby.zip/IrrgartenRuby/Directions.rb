module Irrgarten
    module Directions
        UP = :up
        DOWN = :down
        LEFT = :left
        RIGHT = :right
    end

end