module Irrgarten
    module Orientation
        VERTICAL = :vertical
        HORIZONTAL = :horizontal
    end
end