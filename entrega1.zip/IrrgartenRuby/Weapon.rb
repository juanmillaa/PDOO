require_relative "CombatElement"
module Irrgarten
  class Weapon < CombatElement
    def initialize(iPower, iUses)
      super(iPower, iUses) 
    end
    
    def attack
      produceEffect 
    end

    def discard
      Dice.discard_element(@uses)
    end
    
    def to_s
      "W" + super
    end
  end
  
end
