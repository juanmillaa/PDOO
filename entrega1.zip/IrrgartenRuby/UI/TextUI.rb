
require 'io/console'
require_relative '../Directions'

module UI

  class TextUI
    @@secuencia = Array.new
    def initialize
      @indice = 0;
      @@secuencia.push(Irrgarten::Directions::UP);
      @@secuencia.push(Irrgarten::Directions::UP);
      for i in 0...20
        @@secuencia.push(Irrgarten::Directions::LEFT)
      end
    end
    #https://gist.github.com/acook/4190379
    def read_char
      STDIN.echo = false
      STDIN.raw!
    
      input = STDIN.getc.chr
      if input == "\e" 
        input << STDIN.read_nonblock(3) rescue nil
        input << STDIN.read_nonblock(2) rescue nil
      end
    ensure
      STDIN.echo = true
      STDIN.cooked!
    
      return input
    end

    def next_move
      output = @@secuencia[@indice]
      @indice +=1
      output
    end

    def show_game(game_state)
      puts game_state.labyrinthv
      puts game_state.log 
     
    end

  end # class   

end # module   


