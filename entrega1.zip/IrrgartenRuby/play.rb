require_relative "GameState"
require_relative "Dice"
require_relative "Shield"
require_relative "Weapon"
require_relative "Labyrinth"
require_relative "Monster"
require_relative "Directions"
require_relative "Game"
require_relative "UI/TextUI"
require_relative "Control/Controller"

module Irrgarten
    class TestP1

        def main 
            n_jugadores = 2
            view = UI::TextUI.new
            game = Irrgarten::Game.new(n_jugadores)
            controller = Control::Controller.new(game,view)
            controller.play
        end

    end

    TestP1.new.main
end