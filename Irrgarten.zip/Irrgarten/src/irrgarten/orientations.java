package irrgarten;

/**
 *
 * @author juanma
 */
 enum Orientation {VERTICAL, HORIZONTAL}