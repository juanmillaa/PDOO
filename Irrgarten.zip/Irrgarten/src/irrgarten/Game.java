package irrgarten;
import java.util.ArrayList;
/**
 *
 * @author juanma
 */
public class Game {

    private static final int MAX_ROUNDS = 10;
    private static final int NROWS = 10;
    private static final int NCOLS = 10;
    
    private int currentPlayerIndex;
    private String log;
    
    private Player currentPlayer;
    private ArrayList<Player> players;
    private ArrayList<Monster> monsters;
    private Labyrinth labyrinth;
    
    
    public Game(int nplayers){
        log = " ";
        players = new ArrayList<>();
        for(int i = 0; i < nplayers; i++){
            Player _player = new Player((char)(i+'0'), Dice.randomIntelligence(),Dice.randomStrength());
            players.add(_player);
        }
        monsters =new ArrayList<>();
        currentPlayerIndex = Dice.whoStarts(nplayers);
        currentPlayer = players.get(currentPlayerIndex);
        labyrinth = new Labyrinth(NROWS, NCOLS, Dice.randomPos(NROWS),Dice.randomPos(NCOLS));
        this.configureLabyrinth();
    }
    private void configureLabyrinth(){
        this.labyrinth.spreadPlayers(players);
        for(int i = 0; i < 3; i++){
            Monster _monster = new Monster(Integer.toString(i),Dice.randomIntelligence(),Dice.randomStrength());
            monsters.add(_monster);
            int row = Dice.randomPos(NROWS);
            int col = Dice.randomPos(NCOLS);
            labyrinth.addMonster(row, col, _monster);
        }
        labyrinth.AddBlock(Orientation.HORIZONTAL,Dice.randomPos(NROWS), Dice.randomPos(NCOLS), Dice.randomPos(NROWS));
        labyrinth.AddBlock(Orientation.VERTICAL,Dice.randomPos(NROWS), Dice.randomPos(NCOLS), Dice.randomPos(NROWS));

    }
    public boolean finished(){
        return (labyrinth.haveAWinner());
    }
        public GameState getGameState(){
        String sPlayers = "";
        for(int i = 0; i < players.size(); i++){
           sPlayers += players.get(i).toString();
            sPlayers += "\n";
        }
        String sMonsters = "";
        for(int i = 0; i < monsters.size(); i++){
           sMonsters += monsters.get(i).toString();
            sMonsters += "\n";
        }
        GameState gState = new GameState(labyrinth.toString(),sPlayers, sMonsters,currentPlayerIndex,finished(),log);
        return gState;
    }
        
       
        private Directions actualDirection(Directions preferredDirection){
            int currentRow = currentPlayer.getRow();
            int currentCol = currentPlayer.getCol();
            ArrayList<Directions> validMoves =  this.labyrinth.validMoves(currentRow,currentCol);
            Directions output = currentPlayer.move(preferredDirection, validMoves);
            return output;
        }
        
        private GameCharacter combat(Monster monster){
            int rounds  = 0;
            GameCharacter winner = GameCharacter.PLAYER;
            float playerAttack = currentPlayer.attack();
            boolean lose = monster.defend(playerAttack);
            while(!lose && rounds < MAX_ROUNDS){
                winner = GameCharacter.MONSTER;
                rounds++;
                float monsterAttack = monster.attack();
                lose = currentPlayer.defend(monsterAttack);
                if(!lose){
                    playerAttack = currentPlayer.attack();
                    winner = GameCharacter.PLAYER;
                    lose = monster.defend(playerAttack);
                }
            }
            this.logRounds(rounds,MAX_ROUNDS);
            return winner;
        }
        
        private void manageResurrection(){
            boolean resurrect = Dice.resurrectPlayer();
            if(resurrect){
                currentPlayer.resurrect();
                this.logResurrected();
            }else{
                this.logPlayerSkipTurn();
            }
        }
        
        private void manageReward(GameCharacter winner){
            if(winner == GameCharacter.PLAYER){
                currentPlayer.receiveReward();
                this.logPlayerWon();
            }else{
                this.logMonsterWon();
            }
        }
        
        public boolean nextStep(Directions preferredDirection){
            this.log = "";
            boolean dead = currentPlayer.dead();
            if(!dead){
                Directions direction = actualDirection(preferredDirection);
                if(direction != preferredDirection){
                    this.logPlayerNoOrders();
                }
                Monster monster = this.labyrinth.putPlayer(direction,currentPlayer);
                if(monster == null){
                    this.logNoMonster();
                }else{
                    GameCharacter winner = combat(monster);
                    this.manageReward(winner);
                }
            }else{
                this.manageResurrection();
            }
            
            boolean endGame = this.finished();
            if(!endGame){
                this.nextPlayer();
            }
            return endGame;
        }
        
        private void nextPlayer(){
            if(this.currentPlayerIndex == players.size() -1){
                currentPlayerIndex = 0;
            }else{
                currentPlayerIndex++;
            }
            this.currentPlayer = this.players.get(currentPlayerIndex);
        }
        
        private void logPlayerWon(){
                   log += "El jugador ha ganado el combate \n";
        }
        private void logMonsterWon(){
                   log += "El monstruo ha ganado el combate \n";
        }
        private void logResurrected(){
                   log += "El jugador ha resucitado\n";
        }
        private void logPlayerSkipTurn(){
                   log += "El jugador pierde el turno por estar muerto\n";
        }
        private void logPlayerNoOrders(){
                   log += "El jugador no ha seguido las instrucciones del jugador humano \n";
        }
        private void logNoMonster(){
                   log += "El jugador se ha movido a una celda vacia o no ha sido posible moverse \n";
        }
        private void logRounds(int rounds, int max){
                   log += "Se han producido " + rounds + " rondas de un total de" + max + " \n";
        }
        
        
}
