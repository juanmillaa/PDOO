package irrgarten;
import java.util.ArrayList;
/**
 *
 * @author juanma
 */
public class Player {
    
    private static final int MAX_WEAPONS = 2;
    private static final int MAX_SHIELDS = 3;
    private static final int INITIAL_HEALTH  = 10;
    private static final int HITS2LOSE = 3;
    
    ArrayList<Weapon> weapons;
    ArrayList<Shield> shields;
    
    private String name;
    private char number;
    private float intelligence;
    private float strength;
    private float  health;
    private int row;
    private int col;
    private int consecutiveHits = 0;
    
    public Player(char number, float intelligence, float strength){
        this.name = "#Player" + number;
        this.number = number;
        this.intelligence = intelligence;
        this.strength = strength;
        this.row = 0;
        this.col = 0;
        this.health = INITIAL_HEALTH;
        this.consecutiveHits = 0;
        weapons = new ArrayList<>();
        shields = new ArrayList<>();
    }
    
    public void resurrect(){
        health = INITIAL_HEALTH;
        weapons.clear();
        shields.clear();
        consecutiveHits = 0;
    }
    
    public int getRow(){
        return row;
    }
    
    public int getCol(){
        return col;
    }
    
    public char getNumber(){
        return number;
    }
    
    public void setPos(int row, int col){
        this.row = row;
        this.col = col;
    }
    
    public boolean dead(){
        return (health <= 0);
    }
    
   public Directions move(Directions direction, ArrayList<Directions> validMoves){
       int size = validMoves.size();
       boolean contained = validMoves.contains(direction);
       if(size > 0 && !contained){
           return validMoves.get(0);
       }else{
           return direction;
       }
   }
   public String toString(){
       String _player = "#Player" + number +"[Intelligence:  " + this.intelligence + ", Health: " + this.health + ", Strength: " + this.strength +"]\n";
       return _player;
   }
    
    public float attack(){
        return (this.strength + this.sumWeapons());
    }
    
    public boolean defend(float receivedAttack){
        return(manageHit(receivedAttack));
    }
    
    private boolean manageHit(float receivedAttack){
        float defense = this.defensiveEnergy();
        if(defense < receivedAttack){
            this.gotWounded();
            this.incConsecutiveHits();
        }else{
            this.resetHits();
        }
        boolean lose = false;
        if(consecutiveHits == HITS2LOSE || this.dead()){
            this.resetHits();
            lose = true;
        }
        return lose;
    }
    private float sumWeapons(){
        float sum = 0;
        for(int i = 0; i < weapons.size(); i++){
            sum += weapons.get(i).attack();
        }
        return sum;
    }
    private float sumShields(){
        float sum = 0;
        for(int i = 0; i < shields.size(); i++){
            sum += shields.get(i).protect();
        }
        return sum;
    }
    
    private void receiveShield(Shield s){
        for(int i = 0; i < shields.size(); i++){
            boolean discard = shields.get(i).discard();
            if(discard){
                shields.remove(shields.get(i));
            }
        }
        int size = shields.size();
        if(size < MAX_SHIELDS){
            shields.add(s);
        }
    }
    private void receiveWeapon(Weapon w){
        for(int i = 0; i < weapons.size(); i++){
            boolean discard = weapons.get(i).discard();
            if(discard){
                weapons.remove(weapons.get(i));
            }
        }
        int size = shields.size();
        if(size < MAX_WEAPONS){
            weapons.add(w);
        }
    }
    public void receiveReward(){
        int wReward = Dice.weaponsReward();
        int sReward = Dice.shieldsReward();
        for(int i = 0; i < wReward; i++){
            Weapon wnew = this.newWeapon();
            this.receiveWeapon(wnew);
        }
        for(int i = 0; i < sReward; i++){
            Shield snew = this.newShield();
            this.receiveShield(snew);
        }
        int extraHealth = Dice.healthReward();
        this.health += extraHealth;
    }
    
    
    private float defensiveEnergy(){
        return (this.intelligence + this.sumShields());
    }
    private Weapon newWeapon(){
        Weapon _weapon =new Weapon(Dice.weaponPower(),Dice.usesLeft());
        return _weapon;
    }
    
    private Shield newShield(){
        Shield _shield =new Shield(Dice.shieldPower(),Dice.usesLeft());
        return _shield;
    }
    
    private void resetHits(){
        this.consecutiveHits =0;
    }
    
    private void gotWounded(){
        this.health--;
    }
    
    private void incConsecutiveHits(){
        this.consecutiveHits++;
    }
    
}
