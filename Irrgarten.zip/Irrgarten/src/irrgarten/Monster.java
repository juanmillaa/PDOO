package irrgarten;
/**
 *
 * @author juanma
 */
public class Monster {
    
    private static int INITIAL_HEALTH = 5;
    private String name;
    private float  strength;
    private float health;
    private float intelligence;
    private int row;
    private int col;
    
    public Monster(String name, float intelligence, float strength){
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
        this.health = INITIAL_HEALTH;
        this.row = 0;
        this.col = 0;
    }
    
    public boolean dead(){
        return (health <= 0);
    }
    
    public float attack(){
        return Dice.intensity(strength);
    }
    
    public void setPos(int row,int col){
        this.row = row;
        this.col = col;
    }
    
    public String toString(){
        return (name + "[" + strength + ", " + health + "]");
    }

    private void gotWounded(){
        --health;
    }
    
    public boolean defend(float receivedAttack){
        boolean isDead = this.dead();
        if(!isDead){
            float defensiveEnergy = Dice.intensity(this.intelligence);
            if(defensiveEnergy < receivedAttack){
                this.gotWounded();
                isDead = dead();
            }
        }
        return isDead;
    }
    
}
