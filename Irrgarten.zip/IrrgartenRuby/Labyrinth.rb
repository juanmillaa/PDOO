require_relative "Directions"
require_relative "Orientation"
require_relative "Dice"
require_relative "Player"
require_relative "Monster"

module Irrgarten
  class Labyrinth
    @@BLOCK_CHAR = 'X'
    @@EMPTY_CHAR = '-'
    @@MONSTER_CHAR = 'M'
    @@COMBAT_CHAR = 'C'
    @@EXIT_CHAR = 'E'
    @@ROW = 0
    @@COL = 1

    def initialize(nRows, nCols, exitRow, exitCol)
      @nRows = nRows
      @nCols = nCols
      @exitRow = exitRow
      @exitCol = exitCol
      @monsters = Array.new(@nRows){Array.new(@nCols)}
      @players = Array.new(@nRows){Array.new(@nCols)}
      @labyrinth = Array.new(@nRows){Array.new(@nCols,@@EMPTY_CHAR)}
      @labyrinth[@exitRow][@exitCol] = @@EXIT_CHAR
    end

    def have_a_winner
      return (@players[@exitRow][@exitCol] != nil)
    end
    
    def to_s
      cadena = "LABERINTO:\tNºFilas = #{@nRows}\tNºColumnas = #{@nCols} \n"
      for i in 0...@nRows
        for j in 0...@nCols
          cadena += @labyrinth[i][j].to_s + "  "
        end
        cadena += "\n"
      end
      return cadena
    end

    def add_monster(row,col,monster)
      if(pos_ok(row,col) && empty_pos(row,col)) then
        @labyrinth[row][col] = @@MONSTER_CHAR
        monster.set_pos(row,col)
        @monsters[row][col] = monster
      end
    end

    def pos_ok(row,col)
      return (0 <= row && row < @nRows && 0 <= col && col < @nCols)
    end

    def empty_pos(row,col)
      if(pos_ok(row,col)) then
        return (@labyrinth[row][col] == @@EMPTY_CHAR)
      end
      return false
    end

    def monster_pos(row,col)
      if(pos_ok(row,col)) then
        return (@labyrinth[row][col] == @@MONSTER_CHAR)
      end
      return false
    end

    def exit_pos(row,col)
      if(pos_ok(row,col)) then
        return (@labyrinth[row][col] == @@EXIT_CHAR)
      end
      return false
    end

    def combat_pos(row,col)
      if(pos_ok(row,col)) then
        return (@labyrinth[row][col] == @@COMBAT_CHAR)
      end
      return false
    end

    def can_step_on(row,col)
      if(pos_ok(row,col)) then
        return (empty_pos(row,col) || monster_pos(row,col) || exit_pos(row, col))
      end
      return false
    end

    def update_old_pos(row,col)
      if(pos_ok(row,col))then
        if(combat_pos(row,col))then
          @labyrinth[row][col] = @@MONSTER_CHAR
        else
          @labyrinth[row][col] = @@EMPTY_CHAR
        end
        @players[row][col] = nil
      end
    end

    def dir_2_pos(row,col, direction)
      pos = Array.new(2)
      final_row = row
      final_col = col
      case direction
      when Directions::LEFT
        final_col -= 1
      when Directions::RIGHT
        final_col += 1
      when Directions::UP
        final_row -= 1
      when Directions::DOWN
        final_row += 1
      end
      pos[0] = final_row
      pos[1] = final_col
      return pos
    end

    def random_empty_pos
      pos = Array.new(2)
      state = true
      while(state)
        pos[0] = Dice.random_pos(@nRows)
        pos[1] = Dice.random_pos(@nCols)
        if(empty_pos(pos[0],pos[1]))then
          state = false
        end
      end
      return pos
    end  

    def valid_moves(row, col)
      output = Array.new
      if(can_step_on(row + 1, col))then
        output.push(Directions::DOWN)
      end
      if(can_step_on(row - 1, col))then
        output.push(Directions::UP)
      end
      if(can_step_on(row, col + 1))then
        output.push(Directions::RIGHT)
      end
      if(can_step_on(row, col - 1))then
        output.push(Directions::LEFT)
      end
      return output
    end

    def add_block(orientation, startRow, startCol, length)
      if(orientation == Orientation::VERTICAL) then
        incRow = 1
        incCol = 0
      else
        incRow = 0
        incCol = 1
      end
      @row = startRow 
      @col = startCol
      
      while(pos_ok(@row, @col) && empty_pos(@row, @col) && length > 0)do
        @labyrinth[@row][@col] = @@BLOCK_CHAR
        length -= 1
        @row += incRow
        @col += incCol
      end
    end

    def put_player(direction, player)
      oldRow = player.row 
      oldCol = player.col
      newPos = self.dir_2_pos(oldRow, oldCol, direction)
      monster = self.put_player2D(oldRow, oldCol, newPos[@@ROW], newPos[@@COL], player)
      return monster 
    end

    def put_player2D(oldRow, oldCol, row, col, player)
      output = nil
      if(can_step_on(row,col))then
        if(pos_ok(oldRow,oldCol))then
          p = @players[oldRow][oldCol]
          if(p == player)then
            self.update_old_pos(oldRow,oldCol)
            @players[oldRow][oldCol] = nil
          end
        end
        monsterPos = monster_pos(row,col)
        if(monsterPos) then
          @labyrinth[row][col] = @@COMBAT_CHAR
          output = @monsters[row][col]
        else
          _number = player.number
          @labyrinth[row][col] = _number
        end
        @players[row][col] = player
        player.set_pos(row,col)
      end
      return output
    end

    def spread_players(players)
      for p in players
        pos = self.random_empty_pos 
        put_player2D(-1, -1, pos[@@ROW], pos[@@COL], p)
      end
    end
    
    private :pos_ok, :empty_pos, :monster_pos, :exit_pos, :combat_pos, :can_step_on, :update_old_pos, :dir_2_pos, :random_empty_pos, :put_player2D

  end
  
end
