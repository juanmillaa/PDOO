module Irrgarten
  class Monster
    @@INITIAL_HEALTH = 5
   

    def initialize(name, intelligence, strength)
      @name = name
      @strength = strength
      @intelligence = intelligence
      @health = @@INITIAL_HEALTH
      @row = 0
      @col = 0
    end

    def set_pos(row, col)
      @row = row
      @col = col
    end

    def dead
      dead = false
      if(@health <= 0)then 
        dead = true
      end
      return dead
    end
    
    def attack
      return Dice.intensity(@strength)
    end

    def to_s
      "#{@name}[#{@strength}, #{@health}]"
    end
     
    def got_wounded
      @health -= 1
    end


    def defend(received_attack)
      isDead = self.dead
      if(!isDead)then 
        defensive_energy = Dice.intensity(@intelligence)
        if(defensive_energy < received_attack)then
          self.got_wounded
          isDead = self.dead
        end
      end
      return isDead
    end
    
    private :got_wounded

  end
  
end
