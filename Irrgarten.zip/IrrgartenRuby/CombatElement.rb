module Irrgarten
  class CombatElement

    def initialize(effect,uses)
      @effect = effect
      @uses = uses
    end

    def discard
      Dice.discardElement(@uses)
    end

    # hay que ponerlo protected MIRAR
    def produceEffect
      if(@uses > 0) then
        @uses -= 1
        return @effect
      end
      0
    end

    def to_s
      "[#{@effect}, #{@uses}]"
    end
    protected :produceEffect

  end
  
end
